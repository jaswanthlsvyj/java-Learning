package guessGame;

import java.util.ArrayList;

public class Game {
    int machineGuess;
    Player p1, p2, p3;

    ArrayList<Player> playersList = new ArrayList<>();

    // Game(String n1, String n2, String n3){
    //     p1 = new Player(n1);
    //     p2 = new Player(n2);
    //     p3 = new Player(n3);
    // }

    void play(){
        this.machineGuess = (int)(Math.random()*9)+1;
        System.out.println("Machine guessed "+ machineGuess);

        while (true) {
            p1.makeGuess();
            p2.makeGuess();
            p3.makeGuess();

            if (checkWinner()){
                System.out.println("Game over");
                break;
            }
        }
    }

    private boolean checkWinner(){
        if(p1.getGuess() == this.machineGuess){
            System.out.println(p1.name + " Won!");
            return true;
        }
        else if (p2.getGuess() == this.machineGuess){
            System.out.println(p2.name + " Won!");
            return true;
        }
        else if (p3.getGuess() == this.machineGuess){
            System.out.println(p3.name + " Won!");
            return true;
        }
        return false;
        
    }
}
