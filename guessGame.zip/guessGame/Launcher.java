package guessGame;

public class Launcher {
    public static void main(String[] args) {
        Game g1 = new Game("Khushi", "Tanu", "Muskan");
        g1.play();
    }
}
